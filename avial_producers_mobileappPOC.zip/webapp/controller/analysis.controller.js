sap.ui.define(["sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/ui/core/routing/History"
    ], function(BaseController, MessageBox, History) {
    "use strict";

    return BaseController.extend("generated.app.controller.analysis", {
    	handleRouteMatched: function (oEvent) {
		var oParams = {};
		
		if (oEvent.mParameters.data.context || oEvent.mParameters.data.masterContext) {
		    var oModel = this.getView ? this.getView().getModel() : null;
		    if (oModel) {
		        oModel.setRefreshAfterChange(true);
		
		        if (oModel.hasPendingChanges()) {
		            oModel.resetChanges();
		        }
		    }
		
		    this.sContext = oEvent.mParameters.data.context;
		    this.sMasterContext = oEvent.mParameters.data.masterContext;
		
		    if (!this.sContext) {
		        this.getView().bindElement("/" + this.sMasterContext, oParams);
		    }
		    else {
		        this.getView().bindElement("/" + this.sContext, oParams);
		    }
		
		}
		
	},
	_onHotspotPress5: function (oEvent) {
		var oBindingContext = oEvent.getSource().getBindingContext();
		
		return new ES6Promise.Promise(function(resolve, reject) {
		
		    this.doNavigate("overview", oBindingContext, resolve, ""
		    );
		}.bind(this));
		
	},
	doNavigate: function (sRouteName, oBindingContext, fnPromiseResolve, sViaRelation) {
		var that = this;
		var sPath = (oBindingContext) ? oBindingContext.getPath() : null;
		var oModel = (oBindingContext) ? oBindingContext.getModel() : null;
		
		var entityNameSet;
		if (sPath !== null && sPath !== "") {
		
		    if (sPath.substring(0, 1) === "/") {
		        sPath = sPath.substring(1);
		    }
		    entityNameSet = sPath.split("(")[0];
		}
		var navigationPropertyName;
		var sMasterContext = this.sMasterContext ? this.sMasterContext : sPath;
		
		if (entityNameSet !== null) {
		    navigationPropertyName = sViaRelation || that.getOwnerComponent().getNavigationPropertyForNavigationWithContext(entityNameSet, sRouteName);
		}
		if (navigationPropertyName !== null && navigationPropertyName !== undefined) {
		    if (navigationPropertyName === "") {
		        this.oRouter.navTo(sRouteName, {
		            context: sPath,
		            masterContext: sMasterContext
		        }, false);
		    } else {
		        oModel.createBindingContext(navigationPropertyName, oBindingContext, null, function (bindingContext) {
		            if (bindingContext) {
		                sPath = bindingContext.getPath();
		                if (sPath.substring(0, 1) === "/") {
		                    sPath = sPath.substring(1);
		                }
		            }
		            else {
		                sPath = "undefined";
		            }
		
		            // If the navigation is a 1-n, sPath would be "undefined" as this is not supported in Build
		            if (sPath === "undefined") {
		                that.oRouter.navTo(sRouteName);
		            } else {
		                that.oRouter.navTo(sRouteName, {
		                    context: sPath,
		                    masterContext: sMasterContext
		                }, false);
		            }
		        });
		    }
		} else {
		    this.oRouter.navTo(sRouteName);
		}
		
		if (typeof fnPromiseResolve === "function") {
		    fnPromiseResolve();
		}
		
	},
	onAfterRendering: function () {
		
        var oBindingParameters;
        
        oBindingParameters = {"path":"/MonthlyProduceSet","parameters":{}};
        this.getView().byId("sap_m_Page_0-06a430502a6710770dc8577a5_S5-9f6151a9aefb1bac0dc85a006_S6-content-sap_chart_LineChart-1493534624481").bindData(oBindingParameters);
        oBindingParameters = {"path":"/producePercentSet","parameters":{}};
        this.getView().byId("sap_m_Page_0-06a430502a6710770dc8577a5_S5-9f6151a9aefb1bac0dc85a006_S6-content-sap_chart_PieChart-1493534860920").bindData(oBindingParameters);


	},
	onInit: function () {
		this.mBindingOptions = {};
        this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        this.oRouter.getTarget("analysis").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));

        var oView = this.getView();
        var oModel = new sap.ui.model.json.JSONModel();
        oView.setModel(oModel, 'staticDataModel');
    
        var oData = [{"dim0":"India","mea0":"296"},{"dim0":"Canada","mea0":"133"},{"dim0":"USA","mea0":"489"},{"dim0":"Japan","mea0":"270"},{"dim0":"Germany","mea0":"350"}];
        oView.getModel("staticDataModel").setData({'sap_m_Page_0-06a430502a6710770dc8577a5_S5-9f6151a9aefb1bac0dc85a006_S6-content-sap_chart_LineChart-1493534624481':oData}, true);
        this.oBindingParameters = {"path":"/MonthlyProduceSet","parameters":{}};
        oView.byId("sap_m_Page_0-06a430502a6710770dc8577a5_S5-9f6151a9aefb1bac0dc85a006_S6-content-sap_chart_LineChart-1493534624481").bindData(this.oBindingParameters);
    
        var oData = [{"dim0":"India","mea0":"296"},{"dim0":"Canada","mea0":"133"},{"dim0":"USA","mea0":"489"},{"dim0":"Japan","mea0":"270"},{"dim0":"Germany","mea0":"350"}];
        oView.getModel("staticDataModel").setData({'sap_m_Page_0-06a430502a6710770dc8577a5_S5-9f6151a9aefb1bac0dc85a006_S6-content-sap_chart_PieChart-1493534860920':oData}, true);
        this.oBindingParameters = {"path":"/producePercentSet","parameters":{}};
        oView.byId("sap_m_Page_0-06a430502a6710770dc8577a5_S5-9f6151a9aefb1bac0dc85a006_S6-content-sap_chart_PieChart-1493534860920").bindData(this.oBindingParameters);
    


	}
});
}, /* bExport= */true);
